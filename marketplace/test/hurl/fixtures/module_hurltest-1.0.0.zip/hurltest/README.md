Fake module for Hurl tests
