<?php
// Fake module used by the Hurl tests of the Marketplace.
